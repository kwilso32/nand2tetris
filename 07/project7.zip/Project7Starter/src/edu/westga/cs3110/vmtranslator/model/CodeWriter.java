package edu.westga.cs3110.vmtranslator.model;

public class CodeWriter {

	private static int eqCounter = 0;
	public static String add() {
		StringBuilder sb = new StringBuilder();
		sb.append("@SP\n");
		sb.append("AM=M-1\n");
		sb.append("D=M\n");
		sb.append("A=A-1\n");
		sb.append("M=M+D\n");
		return sb.toString();
	}
	
	public static String sub() {
		StringBuilder sb = new StringBuilder();
		sb.append("@SP\n");
		sb.append("AM=M-1\n");
		sb.append("D=M\n");
		sb.append("A=A-1\n");
		sb.append("M=M-D\n");
		return sb.toString();
	}
	
	public static String neg() {
		StringBuilder sb = new StringBuilder();
		sb.append("@SP\n");
		sb.append("A=M-1\n");
		sb.append("M=-M\n");
		return sb.toString();
	}
	
	public static String eq() {
		StringBuilder sb = new StringBuilder();
		sb.append("@SP\n");
		sb.append("AM=M-1\n");
		sb.append("D=M\n");
		sb.append("A=A-1\n");
		sb.append("D=M-D\n");
		sb.append("@EQ_JUMP" + eqCounter+ "\n");
		sb.append("D;JEQ\n");
		sb.append("D=-1\n");
		sb.append("(EQ_JUMP" + eqCounter + ")\n");
		sb.append("@SP\n");
		sb.append("A=M-1\n");
		sb.append("M=!D\n");
		eqCounter++;
		return sb.toString();
	}
	public static String gt() {
		StringBuilder sb = new StringBuilder();
		sb.append("@SP\n");
		sb.append("AM=M-1\n");
		sb.append("D=M\n");
		sb.append("A=A-1\n");
		sb.append("D=M-D\n");
		sb.append("@GT_JUMP" + eqCounter+ "\n");
		sb.append("D;JGT\n");
		sb.append("D=-1\n");
		sb.append("(GT_JUMP" + eqCounter + ")\n");
		sb.append("@SP\n");
		sb.append("A=M-1\n");
		sb.append("M=!D\n");
		eqCounter++;
		return sb.toString();
	}
	public static String lt() {
		StringBuilder sb = new StringBuilder();
		sb.append("@SP\n");
		sb.append("AM=M-1\n");
		sb.append("D=M\n");
		sb.append("A=A-1\n");
		sb.append("D=M-D\n");
		sb.append("@LT_JUMP" + eqCounter+ "\n");
		sb.append("D;JLT\n");
		sb.append("D=-1\n");
		sb.append("(LT_JUMP" + eqCounter + ")\n");
		sb.append("@SP\n");
		sb.append("A=M-1\n");
		sb.append("M=!D\n");
		eqCounter++;
		return sb.toString();
	}
	public static String and() {
		StringBuilder sb = new StringBuilder();
		sb.append("@SP\n");
		sb.append("AM=M-1\n");
		sb.append("D=M\n");
		sb.append("A=A-1\n");
		sb.append("M=M&D\n");
		return sb.toString();
	}
	public static String or() {
		StringBuilder sb = new StringBuilder();
		sb.append("@SP\n");
		sb.append("AM=M-1\n");
		sb.append("D=M\n");
		sb.append("A=A-1\n");
		sb.append("M=M|D\n");
		return sb.toString();
	}
	public static String not() {
		StringBuilder sb = new StringBuilder();
		sb.append("@SP\n");
		sb.append("A=M-1\n");
		sb.append("M=!M\n");
		return sb.toString();
	}
	
	public static String static_pop(String name, int offset) {
		String location = "@" + name + "." + offset + "\n";
		StringBuilder sb = new StringBuilder();

		sb.append("@SP\n");
		sb.append("AM=M-1\n");
		sb.append("D=M\n");
		sb.append(location);
		sb.append("M=D\n");

		return sb.toString();
	}
	
	public static String static_push(String name, int offset) {
		
		return null;
	}
	
	public static String push(String segment, int offset) {
		StringBuilder sb = new StringBuilder();
		switch(segment) {
		case "local":
		
		case "constant":
			
		case "static":
			
		case "pointer":
			
		case "temp":
		}

		return sb.toString();
	}
	
	public static String pop(String segment, int offset) {
		StringBuilder sb = new StringBuilder();
		switch(segment) {
		case "local":
		
		case "constant":
			
		case "static":
			
		case "pointer":
			
		case "temp":
		}

		return sb.toString();
	}
}
