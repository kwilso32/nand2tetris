package edu.westga.cs3110.vmtranslator.controller;

import java.io.*;
import edu.westga.cs3110.vmtranslator.model.Parser;

public class Main {

	public static void main(String[] args) {
		if( args == null || args.length == 0){
	  	      System.err.println("Need VM code filename");
	  	      System.exit(1);
	        } 
	        Parser parser = new Parser(args[0]);
	        String output_filename = args[0].substring(0, args[0].length()-2)+"asm";
	        PrintWriter writer = null;
	        try{
	          writer = new PrintWriter(output_filename);
	        }
	        catch(FileNotFoundException err){
	  	        System.err.println("Can't create file: "+output_filename);
	  	        System.exit(1);
	        }
	        while(parser.hasNext())
	  	        writer.println(parser.parseNext());
	        writer.close();

	}

}
